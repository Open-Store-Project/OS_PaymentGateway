﻿Open Store Payment Gateway
==========================

This project is an exmaple project that can be used as a starting point for a payment gateway plugin, by using the VS template.

 


